use strict;

my $dirname = './All';
opendir(DIR, $dirname) or die "Could not open $dirname\n";
mkdir "output";
while (my $filename = readdir(DIR)) {
	chomp($filename);
	if($filename =~ /.fasta/){
		my $out_1= "./output/".$filename;
		$out_1=~s/\.fasta/_output_1.csv/g;
		my $out_2= "./output/".$filename;
                $out_2=~s/\.fasta/_output_2.csv/g;
		my $out= "./output/".$filename;
                $out=~s/\.fasta/_output.csv/g;
		my $in="./All/".$filename;
		system"./All/genosig/bin/genosig generate contigs -i $in -m 100 -r -t karl 2 | perl -pe \"s\/\,\/\\t\/g\" > $out_1";
		system"./All/genosig/bin/genosig generate contigs -i $in -m 100 -r -t karl 3 | perl -pe \"s\/\,\/\\t\/g\" | cut -f2-65 > $out_2";
		system "paste  $out_1  $out_2 > $out";		
	unlink($out_1);unlink($out_2);
	}
}

closedir(DIR);
