usage: run.py [-h] [-m mode] [-i path]

Welcome to our tool, make sure your files exsit in the data folder!
#example: $ python run.py -m compare -i ./data/x_data.csv

optional arguments:
  -h, --help            show this help message and exit
  -m mode, --mode mode  PCA or compare
  -i path, --input path
                        The path to your file
#example:
$ python run.py -m compare -i ./data/x_data.csv

