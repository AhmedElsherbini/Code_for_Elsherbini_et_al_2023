#import lib
import pandas as pd
import numpy as np
from utils import *
from sklearn.preprocessing import LabelEncoder, LabelBinarizer, OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
#import pickle
import warnings
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from xgboost import XGBClassifier
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold

#!conda install -c conda-forge xgboost





def trainML_model(f_name):
    data, X, y1, y2, y3, t1, t2, t3 = load_train_data(f_name)
    Features = np.asarray(X, dtype= float)
    Labels1 = np.asarray(y1)
    Labels2 = np.asarray(y2)
    #Labels3 = np.asarray(y3)
    Col = data.columns[1:-3]
    
    #let's divide the data 30 % for learning and 70 % for testing
    X_train1, X_val1, y_train1, y_val1 = train_test_split(Features, Labels1, test_size=0.9, random_state=42, stratify= Labels1)
    X_train2, X_val2, y_train2, y_val2 = train_test_split(Features, Labels2, test_size=0.9, random_state=42, stratify= Labels2)




#####################################################################################
    
    
    clf = RandomForestClassifier(n_estimators = 10,criterion = 'entropy', random_state = 0)
    RF_clf, RF_train_performance, RF_val_performance, RF_c_report, RF_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    scores = cross_val_score(clf, Features, Labels1, cv=10)
    print("%0.2f accuracy of RF_clade with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df = pd.DataFrame(RF_c_report).transpose()
    df2 = pd.DataFrame(scores)
    df.to_csv( 'result/RF_clade_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_RF_clade_report_of_%s.csv'%(f_name[7:-4]))
    # save the model to disk
    #pickle.dump(RF_clf, open('./models/cladeRF_model.sav', 'wb'))


    

    RF_clf, RF_train_performance2, RF_val_performance2, RF_c_report, RF_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    scores = cross_val_score(clf, Features, Labels2, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of RF_cont with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df = pd.DataFrame(RF_c_report).transpose()
    df.to_csv( 'result/RF_cont_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_RF_cont_report_of_%s.csv'%(f_name[7:-4]))
    # save the model to disk
    #pickle.dump(RF_clf, open('./models/contRF_model.sav', 'wb'))

 
    #####################################################################################

    clf = DecisionTreeClassifier(criterion = 'entropy', max_depth=9, random_state = 0)
    DT_clf, DT_train_performance, DT_val_performance, DT_c_report, DT_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    scores = cross_val_score(clf, Features, Labels1, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of DT_clade with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df = pd.DataFrame(DT_c_report).transpose()
    df.to_csv( 'result/DT_clades_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_DT_clade_report_of_%s.csv'%(f_name[7:-4]))

    DT_clf, DT_train_performance2, DT_val_performance2, DT_c_report, DT_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    scores = cross_val_score(clf, Features, Labels2, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of DT_cont with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df = pd.DataFrame(DT_c_report).transpose()
    df.to_csv( 'result/DT_cont_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_DT_cont_report_of_%s.csv'%(f_name[7:-4]))
#####################################################################################
   
    clf = SVC(kernel = 'linear', random_state = 0, max_iter=200)
    SVM_clf, SVM_train_performance, SVM_val_performance, SVM_c_report, SVM_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    df = pd.DataFrame(SVM_c_report).transpose()
    scores = cross_val_score(clf, Features, Labels1, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of SVM_clade with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df.to_csv( 'result/SVM_clade_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_SVM_clade_report_of_%s.csv'%(f_name[7:-4]))

    SVM_clf, SVM_train_performance2, SVM_val_performance2, SVM_c_report, SVM_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    scores = cross_val_score(clf, Features, Labels2, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of SVM_cont with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df = pd.DataFrame(SVM_c_report).transpose()
    df.to_csv( 'result/SVM_cont_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_SVM_cont_report_of_%s.csv'%(f_name[7:-4]))
#####################################################################################
    clf = SVC(C = 100, kernel = 'rbf', cache_size = 10*1024, max_iter=200)
    RBF_clf, RBF_train_performance, RBF_val_performance, RBF_c_report, RBF_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    df = pd.DataFrame(RBF_c_report).transpose()
    scores = cross_val_score(clf, Features, Labels1, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of RBF_clade with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df.to_csv( 'result/RBF_clade_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_RBF_clade_report_of_%s.csv'%(f_name[7:-4]))

    RBF_clf, RBF_train_performance2, RBF_val_performance2, RBF_c_report, RBF_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    scores = cross_val_score(clf, Features, Labels2, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of RBF_cont with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df = pd.DataFrame(RBF_c_report).transpose()
    df.to_csv( 'result/RBF_cont_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_RBF_cont_report_of_%s.csv'%(f_name[7:-4]))
#####################################################################################
    clf = LogisticRegression(random_state = 0)
    LR_clf, LR_train_performance, LR_val_performance, LR_c_report, LR_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    df = pd.DataFrame(LR_c_report).transpose()
    scores = cross_val_score(clf, Features, Labels1, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of LR_clade with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df.to_csv( 'result/LR_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_LR_clade_report_of_%s.csv'%(f_name[7:-4]))

    LR_clf, LR_train_performance2, LR_val_performance2, LR_c_report, LR_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    scores = cross_val_score(clf, Features, Labels2, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of LR_cont with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df = pd.DataFrame(LR_c_report).transpose()
    df.to_csv( 'result/LR_cont_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_LR_cont_report_of_%s.csv'%(f_name[7:-4]))
#####################################################################################
    clf = GaussianNB()
    NB_clf, NB_train_performance, NB_val_performance, NB_c_report, NB_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    scores = cross_val_score(clf, Features, Labels1, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of NB_clade with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df = pd.DataFrame(NB_c_report).transpose()
    df.to_csv( 'result/NB_clade_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_NB_clade_clade_report_of_%s.csv'%(f_name[7:-4]))
    

    NB_clf, NB_train_performance2, NB_val_performance2, NB_c_report, NB_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    scores = cross_val_score(clf, Features, Labels2, cv=10)
    df2 = pd.DataFrame(scores)
    print("%0.2f accuracy of NB_cont with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    df = pd.DataFrame(NB_c_report).transpose()
    df.to_csv( 'result/NB_cont_report_of_%s.csv'%(f_name[7:-4]))
    df2.to_csv( 'result/CV_accuracy_NB_cont_report_of_%s.csv'%(f_name[7:-4]))
####################################################################################################
     
    #clf = XGBClassifier()
    #xg_clf, xg_train_performance, xg_val_performance, xg_c_report, xg_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    #kfold = KFold(n_splits=10, random_state= None)
    #scores = cross_val_score(clf, Features, Labels1, cv=kfold)
    #df2 = pd.DataFrame(scores)
    #print("%0.2f accuracy of XGB_clade with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    #df = pd.DataFrame(xg_c_report).transpose()
    #df.to_csv( 'result/xg_clade_report_of_%s.csv'%(f_name[7:-4]))
    #df2.to_csv( 'result/CV_accuracy_xg_clade_report_of_%s.csv'%(f_name[7:-4]))
    # save the model to disk
    #pickle.dump(RF_clf, open('./models/cladeRF_model.sav', 'wb'))
  

    
    #xg_clf, xg_train_performance2, xg_val_performance2, xg_c_report, xg_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    #scores = cross_val_score(clf, Features, Labels2, cv=kfold)
    #df2 = pd.DataFrame(scores)
    #print("%0.2f accuracy of XGB_cont with a standard deviation of %0.2f" % (scores.mean(), scores.std()))
    #df = pd.DataFrame(xg_c_report).transpose()
    #df.to_csv( 'result/xg_cont_report_of_%s.csv'%(f_name[7:-4]))
    #df2.to_csv( 'result/CV_accuracy_xg_cont_report_of_%s.csv'%(f_name[7:-4]))
    # save the model to disk
    #pickle.dump(RF_clf, open('./models/contRF_model.sav', 'wb'))
##################################################################################### 
    
    #a plot for the clade
    x=['SVM.L', 'SVM.RBF','L.R', 'N.B','D.T', 'R.F']
    
    y=[SVM_train_performance, RBF_train_performance, LR_train_performance, 
       NB_train_performance, DT_train_performance, RF_train_performance]

    z=[SVM_val_performance, RBF_val_performance, LR_val_performance, 
       NB_val_performance, DT_val_performance, RF_val_performance]

    plot_ml_accuracy(x, y, z, f_name)
##################################################################################### 
    
    #a plot for the cont
    x1=['SVM.L', 'SVM.RBF','L.R', 'N.B','D.T', 'R.F']
    
    y1=[SVM_train_performance2, RBF_train_performance2, LR_train_performance2, 
       NB_train_performance2, DT_train_performance2, RF_train_performance2]

    z1=[SVM_val_performance2, RBF_val_performance2, LR_val_performance2, 
       NB_val_performance2, DT_val_performance2, RF_val_performance2]
    #####################################
    plot_ml_accuracy1(x1, y1, z1, f_name)
    

    
  
