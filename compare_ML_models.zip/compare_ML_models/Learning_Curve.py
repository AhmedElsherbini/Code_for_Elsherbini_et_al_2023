#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 31 14:59:36 2021

@author: ahmed
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jul 18 14:45:01 2021

@author: ahmed
"""

##########################
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.utils import shuffle
from sklearn.datasets import load_digits
from sklearn.model_selection import learning_curve, ShuffleSplit, train_test_split
from sklearn.preprocessing import LabelEncoder, LabelBinarizer, OneHotEncoder, StandardScaler
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix, roc_auc_score, matthews_corrcoef

from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from utils import *
from xgboost import XGBClassifier
import warnings
warnings.filterwarnings("ignore")
    
##https://scikit-learn.org/stable/auto_examples/model_selection/plot_learning_curve.html
##############################################################################################
def plot_learning_curve(estimator, title, X, y, axes=None, ylim=None, cv=None,
                        n_jobs=None, train_sizes=np.linspace(.1, 1.0, 5)):


    train_sizes, train_scores, test_scores, fit_times, _ = \
        learning_curve(estimator, X, y, cv=cv, n_jobs=n_jobs,
                       train_sizes=train_sizes,
                       return_times=True)
    train_scores_mean = np.mean(train_scores, axis=1)
    train_scores_std = np.std(train_scores, axis=1)
    test_scores_mean = np.mean(test_scores, axis=1)
    test_scores_std = np.std(test_scores, axis=1)
    fit_times_mean = np.mean(fit_times, axis=1)
    fit_times_std = np.std(fit_times, axis=1)


    if axes is None:
        _, axes = plt.subplots(1, 2, figsize=(20, 5))

    #axes[0].set_title(title)
    if ylim is not None:
        axes[0].set_ylim(*ylim)

    # Plot learning curve
    axes[0].plot(train_sizes, train_scores_mean, 'o-', color="r",
                 label="Training score")
    axes[0].plot(train_sizes, test_scores_mean, 'o-', color="g",
                 label="Cross-validation score")
    axes[0].fill_between(train_sizes, train_scores_mean - train_scores_std,
                         train_scores_mean + train_scores_std, alpha=0.1,
                         color="r")
    axes[0].fill_between(train_sizes, test_scores_mean - test_scores_std,
                         test_scores_mean + test_scores_std, alpha=0.1,
                         color="g")
    axes[0].set_xlabel("Training examples")
    axes[0].set_ylabel("Score")
    axes[0].set_title("Performance of the %s"%(title))
    axes[0].grid()
    axes[0].legend(loc="best")

    # Plot n_samples vs fit_times
    # axes[1].plot(train_sizes, fit_times_mean, 'o-')
    # axes[1].fill_between(train_sizes, fit_times_mean - fit_times_std,
    #                      fit_times_mean + fit_times_std, alpha=0.1)
    # axes[1].set_xlabel("Training examples")
    # axes[1].set_ylabel("fit_times")
    # axes[1].set_title("Scalability of the model")

    # Plot fit_time vs score
    axes[1].plot(fit_times_mean, test_scores_mean, 'o-')
    axes[1].fill_between(fit_times_mean, test_scores_mean - test_scores_std,
                         test_scores_mean + test_scores_std, alpha=0.1)
    axes[1].set_xlabel("fit_times")
    axes[1].set_ylabel("Score")
    axes[1].set_title("Performance of the %s"%(title))
    axes[1].grid()
    
    return plt
################################################################################
#loading the training dataset

####################
def learn_curve(f_name):
    X = pd.read_csv(f_name)
    X = X.fillna(X.mean())
    y = pd.read_csv(f_name[:7]+'y'+f_name[8:])
    data = pd.merge(X, y, on='ID')
    data = shuffle(data)
    
    y1 = data.iloc[:, -3]
    y2 = data.iloc[:, -2]
    y3 = data.iloc[:, -1]
    X = data.iloc[:, 1:-3]
    t1 = list(np.unique(y1))
    t2 = list(np.unique(y2))
    t3 = list(np.unique(y3))
    
    Features = np.asarray(X, dtype= float)
    Labels1 = np.asarray(y1)
    Labels2 = np.asarray(y2)
    Labels3 = np.asarray(y3)
    Col = data.columns[1:-3]
    #'s divide the data 30 % for learning and 70 % for testing
    X_train1, X_val1, y_train1, y_val1 = train_test_split(Features, Labels1, test_size=0.7, random_state=42, stratify= Labels1)
    X_train2, X_val2, y_train2, y_val2 = train_test_split(Features, Labels2, test_size=0.7, random_state=42, stratify= Labels2)
    
    
    
    ######################################################
    clf = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 0)
    RF_clf, RF_train_performance, RF_val_performance, RF_c_report, RF_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "R. forest",X_train1, y_train1, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/R.forest_clade.jpg")
      
      
    clf = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 0)
    RF_clf, RF_train_performance2, RF_val_performance2, RF_c_report, RF_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "R. forest",X_train2, y_train2, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/R.forest_cont.jpg")
    
    ######################################################
    """
    clf = XGBClassifier(eval_metric='mlogloss')
    xg_clf, xg_train_performance, xg_val_performance, xg_c_report, xg_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    kfold = KFold(n_splits=10)
    evalset = [(X_train1, y_train1), (X_val1,y_val1)]
    fig = plot_learning_curve(clf, "X_G_Boost",X_train1, y_train1, ylim=(0, 1) ,n_jobs=-1)
    fig.savefig("result/X_G_boost_clade.jpg")
      
      
    xg_clf, xg_train_performance2, xg_val_performance2, xg_c_report, xg_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    evalset = [(X_train, y_train), (X_test,y_test)]
    kfold = KFold(n_splits=10)
    results = cross_val_score(clf, Features, Labels1, cv=kfold)
    fig = plot_learning_curve(clf, "X_G_boost",X_train2, y_train2, ylim=(0, 1),n_jobs=-1)
    fig.savefig("result/X_G_boost_cont.jpg")
    """
    #####################################################################################
    
    clf = DecisionTreeClassifier(criterion = 'entropy', max_depth=9, random_state = 0)
    DT_clf, DT_train_performance, DT_val_performance, DT_c_report, DT_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "D.tree",X_train1, y_train1, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/D.Tree_clade.jpg")
     
    
    clf = DecisionTreeClassifier(criterion = 'entropy', max_depth=9, random_state = 0)
    DT_clf, DT_train_performance2, DT_val_performance2, DT_c_report, DT_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "D.tree",X_train2, y_train2, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/D.Tree_cont.jpg")
     
    #####################################################################################
       
    clf = SVC(kernel = 'linear', random_state = 0)
    SVM_clf, SVM_train_performance, SVM_val_performance, SVM_c_report, SVM_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "D.tree",X_train1, y_train1, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/SVM_linear_clade.jpg")
    
    clf = SVC(kernel = 'linear', random_state = 0)
    SVM_clf, SVM_train_performance2, SVM_val_performance2, SVM_c_report, SVM_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "SVM_linear",X_train2, y_train2, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/SVM_linaer_cont.jpg")
    
    ####################################################################################
    clf = SVC(C = 100, kernel = 'rbf', cache_size = 10*1024)
    RBF_clf, RBF_train_performance, RBF_val_performance, RBF_c_report, RBF_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "SVM_RBF",X_train1, y_train1, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/SVM_clade_RBF.jpg")
    
    clf = SVC(C = 100, kernel = 'rbf', cache_size = 10*1024)
    RBF_clf, RBF_train_performance2, RBF_val_performance2, RBF_c_report, RBF_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "SVM_RBF",X_train2, y_train2, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/SVM_cont_RBF.jpg")
    
    #####################################################################################
    
    clf = LogisticRegression()
    LR_clf, LR_train_performance, LR_val_performance, LR_c_report, LR_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "LR",X_train1, y_train1, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/LR_clade.jpg")
    
    
    clf = LogisticRegression()
    LR_clf, LR_train_performance2, LR_val_performance2, LR_c_report, LR_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "LR",X_train2, y_train2, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/LR_cont.jpg")
    
    
    #####################################################################################
    clf = GaussianNB()
    NB_clf, NB_train_performance, NB_val_performance, NB_c_report, NB_cm = train_test(clf, X_train1, y_train1, X_val1, y_val1, t1)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "NB",X_train1, y_train1, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/NB_clade.jpg")
    
    
    clf = GaussianNB()
    NB_clf, NB_train_performance2, NB_val_performance2, NB_c_report, NB_cm = train_test(clf, X_train2, y_train2, X_val2, y_val2, t2)
    cv = ShuffleSplit(n_splits=100, test_size=0.7, random_state=0)
    fig = plot_learning_curve(clf, "NB",X_train2, y_train2, ylim=(0, 1), cv=cv ,n_jobs=4)
    fig.savefig("result/NB_cont.jpg")

 
