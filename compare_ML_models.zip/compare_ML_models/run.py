# Import the argparse library
import argparse
import os
import sys
from pca import PCA_model
from train import *
from test import *
from Learning_Curve import *
#update: 4-08-2021
#####################
# Create the parser
my_parser = argparse.ArgumentParser(description='Welcome to our tool, make sure your files exsit in the data folder!')
print("$ python run.py -m compare -i ./data/x_data.csv")
# Add the arguments



my_parser.add_argument('-m','--mode',
                       action='store',
                        metavar='mode',
                       type=str,
                       help='PCA or compare')

my_parser.add_argument('-i','--input',
                       action='store',
                       metavar='path',
                       type=str,
                       help='The path to your file')

# Execute the parse_args() method
args = my_parser.parse_args()
###############
fg  = args.mode
f_name = args.input
################
if (fg == "PCA"):
      PCA_model(f_name)

elif (fg == "compare"):
      trainML_model(f_name)
      #learn_curve(f_name)

