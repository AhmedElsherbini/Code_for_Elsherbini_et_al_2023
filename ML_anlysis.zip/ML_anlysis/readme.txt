$ python run.py -m compare -i ./data/x_data.csv
usage: run.py [-h] [-m mode] [-i input]

Welcome to our tool, make sure your files exsit in the data folder!

optional arguments:
  -h, --help            show this help message and exit
  -m mode, --mode mode  PCA or train or test
  -i input, --input input
                        the path to your file

